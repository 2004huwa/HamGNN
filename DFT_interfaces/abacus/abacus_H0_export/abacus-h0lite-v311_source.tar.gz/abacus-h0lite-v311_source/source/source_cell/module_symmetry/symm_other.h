/**
 * @file symm_other.h
 * @brief Other symmetry-related functions.
 */
#ifndef SYMM_OTHER_H
#define SYMM_OTHER_H

#include "source_base/vector3.h"
#include "source_base/global_function.h"
namespace ModuleSymmetry
{
namespace Symm_Other
{
    /**
     * @brief Print lattice information.
     *
     * @param ibrav Bravais lattice type
     * @param cel_const lattice constants
     * @param ofs_running output file stream
     */
    void print1(const int &ibrav, const double *cel_const, std::ofstream &ofs_running);

    /**
     * @brief Check right-hand sense of three vectors.
     *
     * @param v1 first vector
     * @param v2 second vector
     * @param v3 third vector
     * @return true if right-handed
     */
    bool right_hand_sense(ModuleBase::Vector3<double> &v1,ModuleBase::Vector3<double> &v2,ModuleBase::Vector3<double> &v3);

    /**
     * @brief Calculate cell volume.
     *
     * @param a first lattice vector
     * @param b second lattice vector
     * @param c third lattice vector
     * @return cell volume
     */
    double celvol(const ModuleBase::Vector3<double> &a, 
        const ModuleBase::Vector3<double> &b, const ModuleBase::Vector3<double> &c);


}
}

#endif
