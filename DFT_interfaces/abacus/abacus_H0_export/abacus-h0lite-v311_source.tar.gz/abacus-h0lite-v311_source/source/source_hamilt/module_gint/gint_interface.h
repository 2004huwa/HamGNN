#pragma once
#include <vector>
#include "source_hamilt/module_hcontainer/hcontainer.h"
#include "gint_type.h"

class Parallel_Orbitals;
class UnitCell;
class Grid_Driver;
class LCAO_HS_Arrays;

namespace ModuleGint
{

void cal_gint_vl(
    const double* vr_eff,
    HContainer<double>* hR);

void cal_gint_vl(
    std::vector<const double*> vr_eff,
    HContainer<std::complex<double>>* hR);

void cal_gint_vl_metagga(
    const double* vr_eff,
    const double* vfork,
    HContainer<double>* hR);

void cal_gint_vl_metagga(
    std::vector<const double*> vr_eff,
    std::vector<const double*> vofk,
    HContainer<std::complex<double>>* hR);

void cal_gint_rho(
    const std::vector<HContainer<double>*>& dm_vec,
    const int nspin,
    double **rho,
    bool is_dm_symm = true);

// gradient density on the grid:
//   [grad rho]_{x,y,z}[is](ir) += sum_{Kk,Ll} D[Kk,Ll] (grad phi_Kk) phi_Ll
// outputs are accumulated, so zero-initialize drho_{x,y,z}[is] (length nrxx) first.
void cal_gint_drho(
    const std::vector<HContainer<double>*>& dm_vec,
    const int nspin,
    double** drho_x,
    double** drho_y,
    double** drho_z);

void cal_gint_tau(
    const std::vector<HContainer<double>*>& dm_vec,
    const int nspin,
    double**tau);

void cal_gint_fvl(
    const int nspin,
    const std::vector<const double*>& vr_eff,
    const std::vector<HContainer<double>*>& dm_vec,
    const bool isforce,
    const bool isstress,
    ModuleBase::matrix* fvl,
    ModuleBase::matrix* svl);

void cal_gint_fvl_meta(
    const int nspin,
    const std::vector<const double*>& vr_eff,
    const std::vector<const double*>& vofk,
    const std::vector<HContainer<double>*>& dm_vec,
    const bool isforce,
    const bool isstress,
    ModuleBase::matrix* fvl,
    ModuleBase::matrix* svl);

void cal_dvlocal_R_sparse(
    const int nspin,
    const int npol,
    const int current_spin,
    const int nlocal,
    const double sparse_thr,
    const double* vr_eff,
    const Parallel_Orbitals& pv,
    const UnitCell& ucell,
    const Grid_Driver& gdriver,
    LCAO_HS_Arrays& hs_arrays);


} // namespace ModuleGint
