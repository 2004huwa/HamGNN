# H0Lite license embedding by HamGNN contributors (2004huwa), 2026-09-06.
# SPDX-License-Identifier: LGPL-3.0-or-later

file(READ "${_license_dir}/ABACUS-LGPL-3.0.txt" H0LITE_ABACUS_LICENSE_TEXT)
file(READ "${_license_dir}/GPL-3.0.txt" H0LITE_GPL_LICENSE_TEXT)
file(READ "${_license_dir}/GCC-Runtime-Library-Exception-3.1.txt" H0LITE_GCC_RUNTIME_LICENSE_TEXT)
file(READ "${_license_dir}/H0Lite-NOTICE.txt" H0LITE_NOTICE_TEXT)
file(READ "${_license_dir}/BLACS-NOTICE.txt" H0LITE_BLACS_NOTICE_TEXT)

set(H0LITE_MKL_LICENSE_DIR "" CACHE PATH
  "License directory from the exact oneMKL installation being linked")
set(_h0lite_mkl_license_dir "${H0LITE_MKL_LICENSE_DIR}")
if(NOT _h0lite_mkl_license_dir)
  set(_h0lite_mkl_license_dir "$ENV{H0LITE_MKL_LICENSE_DIR}")
endif()
if(NOT _h0lite_mkl_license_dir)
  # Follow the linked archive, including symlinks in unified oneAPI layouts.
  get_filename_component(_mkl_core_real "${MKL_CORE}" REALPATH)
  get_filename_component(_mkl_parent "${_mkl_core_real}" DIRECTORY)
  foreach(_level RANGE 0 3)
    foreach(_suffix IN ITEMS licensing share/doc/mkl/licensing)
      if(EXISTS "${_mkl_parent}/${_suffix}/license.txt"
          AND EXISTS "${_mkl_parent}/${_suffix}/third-party-programs.txt")
        set(_h0lite_mkl_license_dir "${_mkl_parent}/${_suffix}")
        break()
      endif()
    endforeach()
    if(_h0lite_mkl_license_dir)
      break()
    endif()
    get_filename_component(_mkl_parent "${_mkl_parent}" DIRECTORY)
  endforeach()
endif()
if(NOT EXISTS "${_h0lite_mkl_license_dir}/license.txt"
    OR NOT EXISTS "${_h0lite_mkl_license_dir}/third-party-programs.txt")
  message(FATAL_ERROR
    "oneMKL license.txt and third-party-programs.txt are required for ${MKL_CORE}. "
    "Set H0LITE_MKL_LICENSE_DIR to the licensing directory from this exact "
    "oneMKL installation (environment variable or -D CMake option).")
endif()
message(STATUS "H0Lite embeds oneMKL notices from: ${_h0lite_mkl_license_dir}")
file(READ "${_h0lite_mkl_license_dir}/license.txt" H0LITE_MKL_LICENSE_TEXT)
file(GLOB _mkl_notice_files CONFIGURE_DEPENDS
  "${_h0lite_mkl_license_dir}/third-party-programs*.txt")
list(SORT _mkl_notice_files)
set(H0LITE_MKL_THIRD_PARTY_TEXT "")
foreach(_notice_file IN LISTS _mkl_notice_files)
  get_filename_component(_notice_name "${_notice_file}" NAME)
  file(READ "${_notice_file}" _notice_text)
  string(APPEND H0LITE_MKL_THIRD_PARTY_TEXT "\n===== ${_notice_name} =====\n${_notice_text}\n")
endforeach()
